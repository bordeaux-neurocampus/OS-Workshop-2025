Creative Commons Attribution 4.0 International

Copyright © 2023 Bordeaux Neurocampus – [CC-BY 4.0 International licence](https://creativecommons.org/licenses/by/4.0/legalcode).