# OS Workshop 2023 - Bordeaux Neurocampus

Website for the Open Science Workshop to be held in October 16-20th 2023 at Bordeaux Neurocampus.

