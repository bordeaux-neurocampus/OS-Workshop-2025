---
layout: default
title: Apply
permalink: /apply
---

Applications are now closed.

PhD students at the University of Bordeaux can now register on ADUM in order to validate doctoral school training hours.

We are looking forward to meeting you!

<!-- 
Applications are now open!

Please complete the following form [here](https://forms.gle/t6dXv9gToHSNGEX27){:target="_blank"}{:rel="noopener noreferrer"} if you want to attend our workshop. 

We are looking forward to hearing from you!
-->